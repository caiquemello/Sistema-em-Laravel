<?php $__env->startSection('titulo','cursos'); ?>
<?php $__env->startSection('conteudo'); ?>

<h2 class="text-center">Lista de Cursos</h2>

 <div class=" row container">
     <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
         
    <div class="card" style="width: 18rem;">
    <img class="card-img-top" src="<?php echo e(asset($curso->imagem)); ?>" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
 </div>
  
   </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>