<?php $__env->startSection('titulo','cursos'); ?>
<?php $__env->startSection('conteudo'); ?>

<div class="container-fluid ">
    <h2 class="text-center">Lista de Cursos</h2>
    <br>
        <div class="row">
            
        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-3">
                <div class="card" style="width: 14rem;"  style="height: 12rem;">
                    <img class="card-img-top p-1" src="<?php echo e($curso->imagem); ?>" alt="Card image cap">
                    <div class="card-body">
                     <hr>
                    <h5 class="card-title text-center"><?php echo e($curso->nome); ?></h5>
                    <p class="card-text text-center"><?php echo e($curso->descricao); ?></p>
                      <Small><p class="card-text text-center">Valor:$ <?php echo e($curso->valor); ?></p></Small>
                      <hr>
                        <a href="#" class="btn btn-primary">ler mais</a>
                </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        
    </div>

  <?php echo e($cursos->links()); ?>

   
</div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>