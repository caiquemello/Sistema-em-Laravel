<?php $__env->startSection('titulo','cursos'); ?>
<?php $__env->startSection('conteudo'); ?>

<h2 class="text-center">Editar Cursos</h2>

<div class=" row container">
   <div class = "col-md-12 ">
        <form action="<?php echo e(route('admin.cursos.salvar')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.cursos.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               <button type="submit" class="btn btn-primary">Salvar</button>
            <br>
            
        </form>
   </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>