<?php $__env->startSection('titulo','cursos'); ?>
<?php $__env->startSection('conteudo'); ?>
 <h2 class="text-center">Adicionar Cursos</h2>
  <div class="row">
      <table class="table">
          <thead>
              <tr>
                  <th></th>
                  <th>Id</th>
                  <th>Nome</th>
                  <th>Descrição</th>
                  <th>Valor</th>
                  <th>Imagem</th>
                  <th>Publicado</th>
                  <th>Ação</th>
              </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                  <td scope="row"></td>
                  <td><?php echo e($registro->id); ?></td>
                   <td><?php echo e($registro->nome); ?></td>
                  <td><?php echo e($registro->descricao); ?></td>
                  <td><?php echo e($registro->valor); ?></td>
              <td><img width="90" height="" src="<?php echo e(asset($registro->imagem)); ?>" alt ="<?php echo e($registro->titulo); ?>"  />  </td>
              <td><?php echo e($registro->publicado); ?></td>
              <td>
              <a class = "btn btn-info" href="<?php echo e(route('admin.cursos.editar',$registro->id)); ?>">Editar</a>
              <a class = "btn btn-danger" href="<?php echo e(route('admin.cursos.deletar',$registro->id)); ?>">Deletar</a>
              </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
          
      </table>

  </div>
  <div class="row">
              <a class = "btn btn-success" href="<?php echo e(route('admin.cursos.adicionar')); ?>">Adicionar</a>
          </div>
          <br><br>
    
<?php $__env->stopSection(); ?>
    



<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>