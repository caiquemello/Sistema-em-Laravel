<?php $__env->startSection('titulo','cursos'); ?>
<?php $__env->startSection('conteudo'); ?>

<h2 class="text-center">Login</h2>

<div class=" row container">
   <div class = "col-md-12 ">
       <?php if(session('status')): ?>
    <div class="alert alert-success">
        {‌{ session('status') }}
    </div>
<?php endif; ?>
        <form action="<?php echo e(route('site.login.entrar')); ?>" method="post" >
                <?php echo e(csrf_field()); ?>

                
        <div class="form-group">
            <label>Email:</label>
        <input type="text" class="form-control" name="email" placeholder="Email">

        <div class="form-group">
            <label>Senha:</label>
        <input type="password" class="form-control" name="senha" placeholder="Senha">
        
         <br>
            
               <button type="submit" class="btn btn-primary">Entrar</button>
           
            
        </form>
   </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>